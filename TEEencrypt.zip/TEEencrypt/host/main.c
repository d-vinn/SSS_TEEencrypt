#include <err.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>

#include <tee_client_api.h>

#include <TEEencrypt_ta.h>

#define MAX_TEXT_LEN 1024
#define RSA_KEY_SIZE 1024
#define RSA_MAX_PLAIN_LEN_1024 86 
#define RSA_CIPHER_LEN_1024 (RSA_KEY_SIZE / 8)

int main(int argc, char *argv[])
{
	TEEC_Result res;
	TEEC_Context ctx;
	TEEC_Session sess;
	TEEC_Operation op;
	TEEC_UUID uuid = TA_TEEencrypt_UUID;
	uint32_t err_origin;

	FILE *fp_input = NULL;
	FILE *fp_key = NULL;
	FILE *fp_output = NULL;
	FILE *fp_output_enc = NULL;
	FILE *fp_output_key = NULL;
	char buffer[MAX_TEXT_LEN] = {0,};
	char keystring[64] = {0, };
	int key_int = 0;
	int len = 0;

	if (argc != 4) {
		return 1;
	}

	res = TEEC_InitializeContext(NULL, &ctx);
	if (res != TEEC_SUCCESS)
		errx(1, "TEEC_InitializeContext failed with code 0x%x", res);

	res = TEEC_OpenSession(&ctx, &sess, &uuid, TEEC_LOGIN_PUBLIC, NULL, NULL, &err_origin);
	if (res != TEEC_SUCCESS) {
		TEEC_FinalizeContext(&ctx);
		errx(1, "TEEC_OpenSession failed with code 0x%x origin 0x%x", res, err_origin);
	}


	if (strcmp(argv[1], "-e") == 0) {
		char *input_file_name = argv[2];
		char *algorithm = argv[3];

		fp_input = fopen(input_file_name, "r");
		if (fp_input == NULL) {
			errx(1, "Failed to open plaintext file: %s", input_file_name);
		}

		if (fgets(buffer, MAX_TEXT_LEN, fp_input) == NULL) {
			errx(1, "Failed to read content from file: %s", input_file_name);
		}
		fclose(fp_input);
		len = strlen(buffer);
		printf("Plaintext read: %s (Length: %d)\n", buffer, len);

		if (strcmp(algorithm, "caesar") == 0) {
			memset(&op, 0, sizeof(op));
			op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_VALUE_INOUT, TEEC_NONE, TEEC_NONE);

			op.params[0].tmpref.buffer = buffer;
			op.params[0].tmpref.size = len;

			op.params[1].value.a = 0;

			printf("Invoking TA to encrypt the text...\n");

			res = TEEC_InvokeCommand(&sess, TA_TEEencrypt_CMD_ENC_VALUE, &op, &err_origin);
			if (res != TEEC_SUCCESS) {
				TEEC_CloseSession(&sess);
				TEEC_FinalizeContext(&ctx);
				errx(1, "TEEC_InvokeCommand failed with code 0x%x origin 0x%x", res, err_origin);
			}

			printf("Encryption successful!\n");
			printf("Ciphertext received: %s\n", (char *)op.params[0].tmpref.buffer);
			printf("Encrypted Key received: %d\n", op.params[1].value.a);

			fp_output_enc = fopen("enc.txt", "w");
			if (fp_output_enc == NULL) {
				errx(1, "Failed to open enc.txt for writing\n");
			}
			fputs((char *)op.params[0].tmpref.buffer, fp_output_enc);
			fclose(fp_output_enc);
			printf("Ciphertext saved to enc.txt\n");

			fp_output_key = fopen("key.txt", "w");
			if (fp_output_key == NULL) {
				errx(1, "Failed to open key.txt for writing\n");
			}
			char key_str[16];
			sprintf(key_str, "%d", op.params[1].value.a);
			fputs(key_str, fp_output_key);
			fclose(fp_output_key);
			printf("Encrypted Key saved to key.txt\n");
		} else if (strcmp(algorithm, "rsa") == 0) {
			printf("\nInvoking TA to generate RSA keys...\n");
        		res = TEEC_InvokeCommand(&sess, TA_TEEencrypt_CMD_RSA_GENKEYS, NULL, NULL);
        		if (res != TEEC_SUCCESS) errx(1, "Key generation failed 0x%x", res);
        
        		memset(&op, 0, sizeof(op));
        		op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INPUT, TEEC_MEMREF_TEMP_OUTPUT, TEEC_NONE, TEEC_NONE);

        		op.params[0].tmpref.buffer = buffer;
        		op.params[0].tmpref.size = len; 

        		char cipher_buffer[RSA_CIPHER_LEN_1024] = {0, }; 
        
        		op.params[1].tmpref.buffer = cipher_buffer;
        		op.params[1].tmpref.size = RSA_CIPHER_LEN_1024; 
        
        		printf("Invoking TA for RSA encryption...\n");
        		res = TEEC_InvokeCommand(&sess, TA_TEEencrypt_CMD_RSA_ENCRYPT, &op, &err_origin);
        		if (res != TEEC_SUCCESS) errx(1, "RSA encryption failed 0x%x", res);

        		printf("RSA Encryption successful! Ciphertext saved to enc_rsa.txt\n");

        		fp_output_enc = fopen("enc_rsa.txt", "wb"); 
        		if (fp_output_enc == NULL) errx(1, "Failed to open enc_rsa.txt");
        
        		fwrite(op.params[1].tmpref.buffer, 1, op.params[1].tmpref.size, fp_output_enc);
        		fclose(fp_output_enc);
		} else {
			printf("invalid algorithm");
		}

	} else if (argc == 4 && strcmp(argv[1], "-d") == 0) {
		char *cipher_file_name = argv[2];
		char *key_file_name = argv[3];

		fp_input = fopen(cipher_file_name, "r");
		fgets(buffer, MAX_TEXT_LEN, fp_input);
		fclose(fp_input);

		fp_key = fopen(key_file_name, "r");
		fgets(keystring, 64, fp_key);
		fclose(fp_key);

		key_int = atoi(keystring);

		memset(&op, 0, sizeof(op));
		op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_VALUE_INOUT, TEEC_NONE, TEEC_NONE);

		op.params[0].tmpref.buffer = buffer;
		op.params[0].tmpref.size = strlen(buffer);

		op.params[1].value.a = key_int; 

		res = TEEC_InvokeCommand(&sess, TA_TEEencrypt_CMD_DEC_VALUE, &op, &err_origin);

		fp_output = fopen("dec.txt", "w");
		fputs((char *)op.params[0].tmpref.buffer, fp_output);
		fclose(fp_output);
		printf("Decryption successful. Plaintext saved to dec.txt\n");

	} else {
		printf("Usage: TEEencrypt -e <plaintext_file>\n");
		printf("       TEEencrypt -d <ciphertext_file> <encrypted_key_file>\n");
		return 1;
	}

	TEEC_CloseSession(&sess);
	TEEC_FinalizeContext(&ctx);

	return 0;
}
